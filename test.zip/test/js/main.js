$(window).load(function(){
  var $container = $('.portfolioContainer');
  $container.isotope({
      filter: '*',
      animationOptions: {
          duration: 750,
          easing: 'linear',
          queue: false
      }
  });

  $('.portfolioFilter a').click(function(){
      $('.portfolioFilter .current').removeClass('current');
      $(this).addClass('current');

      var selector = $(this).attr('data-filter');
      $container.isotope({
          filter: selector,
          animationOptions: {
              duration: 750,
              easing: 'linear',
              queue: false
          }
       });
       return false;
  }); 
});


$(".filters ul li").click(function() {
  $(".filters ul li").removeClass("active");
  $(this).addClass("active");

  var data = $(this).attr("data-filter");
  $grid.isotope({
    filter: data
  });
});

var $grid = $(".grid").isotope({
  itemSelector: ".all",
  percentPosition: true,
  masonry: {
    columnWidth: ".all"
  }
});




/*======================================
  =            Hamburger Menu            =
  ======================================*/

  $(".ham").click(function() {
    $('.menus').slideToggle();
    $(this).toggleClass('active');
    $(this).toggleClass('rb-close');
    
  });

/*===== End of Hamburger Menu ======*/
$('.owl-carousel').owlCarousel({
  loop:true,
  margin:10,
  nav:true,
  responsive:{
      0:{
          items:1
      }
  }
})


